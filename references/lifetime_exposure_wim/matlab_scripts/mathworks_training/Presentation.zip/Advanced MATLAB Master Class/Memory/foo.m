function y = foo(x,a,b)

% Copyright 2007 The MathWorks, Inc.

a(1) = a(1) + 12;
y = a*x+b;
