function y = fquiz1(x,a,b)

% Copyright 2007 The MathWorks, Inc.

% FUNCTION_QUIZ1    A sample function

%% What type of function is function_quiz1?
y = a*x + b;

