function y = fquiz5(x)

% Copyright 2007 The MathWorks, Inc.

%% What kind of function is MAKELINE?
a = 3;
b = 5;
y = makeline(x);

    function y = makeline(x)
        y = a*x + b;
    end

end

