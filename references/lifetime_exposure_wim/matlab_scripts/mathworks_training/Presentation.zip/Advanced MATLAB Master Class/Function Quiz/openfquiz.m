
% Copyright 2007 The MathWorks, Inc.

% OPEN_FUNCTION_QUIZ   Open all files in function quiz in editor
for ii=7:-1:1
    edit(['fquiz' num2str(ii)])
end
